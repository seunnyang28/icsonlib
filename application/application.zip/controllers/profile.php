<?
	class Profile extends CI_Controller{
		public function Profile(){
			parent::__construct();
			$this->load->model('user_model');
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->helper('form');
		}

		public function index(){
			$data["title"] = "Profile - ICS Library System";
			
			$username = $this->session->userdata('username');
			$id = $this->session->userdata('id');
			
			$data['query'] = $this->user_model->user_profile($username, $id);
			
			$this->load->view("profile_view", $data);
			
		}
	}
?>