<?php

class Login extends CI_Controller{
	public function Login(){
		parent::__construct();
		$this->load->model('user_model');
		$this->load->library('session');
	}

	public function index(){
		$username = $_POST["username"];
		$password = md5($_POST["password"]);
		
		if($this->user_model->user_exists($username, $password)){
			$query=$this->user_model->get_user_data($username, $password);
			foreach($query as $row){
				$id = $row->id;
				$user_type = $row->user_type;
				break;
			}
			
			$sessionData = array('loggedIn' => true, 'id' => $id, 'user_type' => $user_type, 'username' => $username);

			$this->session->set_userdata($sessionData);
			
			redirect(base_url());
		}
	}
}
?>