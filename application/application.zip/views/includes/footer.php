	</body>
	<!-- Link scripts here -->
	<script type="text/javascript" src="<?=base_url().'/js/scripts.js'?>"></script>
</html>