<?
	session_start();
	
?>

<html>
	<head>
		<title><?=$title?></title>
	</head>

	<body>
		<?php foreach($query as $row): ?>
			<h3><?=$row->username?></h3>
			<p><?=$row->password?></p>
		
		<?php endforeach; ?>
		
		
		
		<fieldset>
			<legend><?=$loginLegend?></legend>
			<br/>
			<form action="<?=base_url().'index.php/login'?>" method="post">
			
				<input type="text" name="username" placeholder="Username" required />
				<input type="password" name="password" placeholder="Password" required />
				<br/>
				
				<br/>
				<input type="submit" name="login" style="color: #fffff" value="Log in"/>
			
			</form>
		</fieldset>
	</body>
</html>